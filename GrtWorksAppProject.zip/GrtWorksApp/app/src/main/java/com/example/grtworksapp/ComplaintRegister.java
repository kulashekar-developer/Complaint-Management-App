package com.example.grtworksapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class ComplaintRegister extends AppCompatActivity {


    private EditText editTextname, editTextemail, editTextlocation, editTextcategory, editTextsubject, editTextmessage;
    private Button submitbtn;

    private FirebaseDatabase db = FirebaseDatabase.getInstance();
    private DatabaseReference root = db.getReference().child("Users");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complaint_register);


        editTextname = findViewById(R.id.name);
        editTextemail = findViewById(R.id.email);
        editTextlocation = findViewById(R.id.location);
        editTextcategory = findViewById(R.id.category);
        editTextsubject = findViewById(R.id.subject);
        editTextmessage = findViewById(R.id.message);
        submitbtn = findViewById(R.id.submitbtn);


        submitbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = editTextname.getText().toString();
                String email = editTextemail.getText().toString();
                String location = editTextlocation.getText().toString();
                String category = editTextcategory.getText().toString();
                String subject = editTextsubject.getText().toString();
                String message = editTextmessage.getText().toString();

                HashMap<String , String> userMap = new HashMap<>();

                userMap.put("Name", name);
                userMap.put("Email", email);
                userMap.put("Location", location);
                userMap.put("Category", category);
                userMap.put("Subject", subject);
                userMap.put("Message", message);

                root.push().setValue(userMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        Toast.makeText(ComplaintRegister.this, "Complaint Registerd Successfully!", Toast.LENGTH_SHORT).show();
                    }
                });




            }
        });




    }
}