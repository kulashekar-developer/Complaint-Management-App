package com.example.grtworksapp;

public class User {

    public String name, email, password, department;

    String firstName, Email, Location, Category, Subject, Message;

    public String getFirstName() {
        return firstName;
    }

    public String getEmail() {
        return Email;
    }

    public String getLocation() {
        return Location;
    }

    public String getCategory() {
        return Category;
    }

    public String getSubject() {
        return Subject;
    }

    public String getMessage() {
        return Message;
    }

    public User(){


    }
    public User(String name, String email, String password, String department){
        this.name = name;
        this.email = email;
        this.password = password;
        this.department = department;
    }

}
