package com.example.grtworksapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class AdminRegister extends AppCompatActivity implements View.OnClickListener {


    private TextView loginpage;
    private EditText editTextname, editTextphone, editTextemail, editTextpassword;
    private Button signupbtn;

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_register);


        mAuth = FirebaseAuth.getInstance();

        loginpage = (TextView) findViewById(R.id.loginpage);
        loginpage.setOnClickListener(this);

        signupbtn = (Button) findViewById(R.id.signupbtn);
        signupbtn.setOnClickListener(this);

        editTextname = (EditText) findViewById(R.id.name);
        editTextphone = (EditText) findViewById(R.id.phone);
        editTextemail = (EditText) findViewById(R.id.email);
        editTextpassword = (EditText) findViewById(R.id.password);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.loginpage:
                startActivity(new Intent(this, AdminLogin.class));
                break;
            case R.id.signupbtn:
                signupbtn();
                break;

        }


    }

    private void signupbtn() {
        String name = editTextname.getText().toString().trim();
        String phone = editTextphone.getText().toString().trim();
        String email = editTextemail.getText().toString().trim();
        String password = editTextpassword.getText().toString().trim();

        if (name.isEmpty()) {
            editTextname.setError("Full name is required!");
            editTextname.requestFocus();
            return;
        }
        if (email.isEmpty()){
            editTextemail.setError("Email is required!");
            editTextemail.requestFocus();
            return;
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            editTextemail.setError("Provide valid email");
            editTextemail.requestFocus();
            return;
        }
        if (password.isEmpty()){
            editTextpassword.setError("Password is required");
            editTextpassword.requestFocus();
            return;
        }
        if (password.length() < 8){
            editTextpassword.setError("Min password length should be 6 characters!");
            editTextpassword.requestFocus();
            return;
        }
        if (!Patterns.PHONE.matcher(phone).matches()){
            editTextphone.setError("Phone number is required");
            editTextphone.requestFocus();
            return;
        }


        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        if (task.isSuccessful()){
                            User user = new User(name, email, password, phone);

                            FirebaseDatabase.getInstance().getReference("Users")
                                    .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                    .setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {

                                    if (task.isSuccessful()){
                                        Toast.makeText(AdminRegister.this,"User has been registered successfully!", Toast.LENGTH_LONG).show();

                                    }else {
                                        Toast.makeText(AdminRegister.this, "Failed to register! Try again!", Toast.LENGTH_LONG).show();

                                    }

                                }
                            });
                        }else {
                            Toast.makeText(AdminRegister.this, "Failed to register", Toast.LENGTH_LONG).show();
                        }
                    }
                });

}
    }
