package com.example.grtworksapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class UserDashboard extends AppCompatActivity implements View.OnClickListener {


    ImageView menubtn;
    CardView complaintbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_dashboard);

        menubtn = findViewById(R.id.menubtn);
        menubtn.setOnClickListener(this);

        complaintbtn = findViewById(R.id.complaintbtn);
        complaintbtn.setOnClickListener(this);


    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.menubtn:
                startActivity(new Intent(this, Menu.class));
                break;
            case  R.id.complaintbtn:
                startActivity(new Intent(this,ComplaintRegister.class));
                break;
        }

    }
}